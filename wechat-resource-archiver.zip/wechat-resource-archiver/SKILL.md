---
name: wechat-resource-archiver
description: Archive content forwarded through WeChat or ClawBot into a local knowledge base. Use when a user forwards a WeChat Official Account article, webpage URL, video-channel card, image, video, audio, document, or text note and asks to save, collect, archive, ingest, or add it to local resources.
---

# WeChat Resource Archiver

Use `scripts/archive_wechat.py` for every archive operation. Return the script's JSON result to the user in concise Chinese. Never claim a video-channel card's underlying video was saved unless ClawBot supplied an actual local media file.

## Choose the input mode

- Public WeChat article or webpage URL: run `archive-url`.
- Local attachment supplied by ClawBot: run `archive-file`. Pass the accompanying message as `--note` when useful.
- Video-channel card or text without an accessible file/URL: run `archive-note`. Preserve all card text and tell the user the original media was not available.
- A message containing both URL and local attachments: archive each item, then report every resulting path.

## Commands

Resolve the skill directory first and invoke its bundled script:

```bash
python3 <skill-dir>/scripts/archive_wechat.py archive-url "<url>"
python3 <skill-dir>/scripts/archive_wechat.py archive-file "<local-path>" --note "<message>"
python3 <skill-dir>/scripts/archive_wechat.py archive-note "<text>" --source "wechat://forwarded-card"
```

The output root defaults to `resource` under the current working directory. Prefer setting `WECHAT_RESOURCE_DIR` to an absolute knowledge-base resource directory in the OpenClaw service environment. `--output <path>` overrides it per call.

## Behavioral rules

1. Preserve provenance: source URL, retrieval time, original filename, SHA-256, and forwarded text where available.
2. Keep source material separate from interpretation. Do not summarize or alter the archived original unless asked.
3. Treat an existing matching URL or file hash as a duplicate. Return the existing path instead of creating another copy.
4. Do not bypass login, access controls, paywalls, DRM, or WeChat verification pages.
5. Do not invent a downloadable URL for video-channel cards. Save the card as a note when no accessible media is supplied.
6. Warn when an article page cannot be fetched and suggest forwarding its public link, copied text, screenshot, or downloaded file.
