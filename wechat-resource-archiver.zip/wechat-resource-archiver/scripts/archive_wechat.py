#!/usr/bin/env python3
"""Archive WeChat-forwarded URLs, files, and notes into a local knowledge base."""

from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from markdownify import markdownify


UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124 Safari/537.36"
BAD_NAME = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


class ArchiveError(RuntimeError):
    pass


def now() -> datetime:
    return datetime.now().astimezone()


def safe_name(value: str, limit: int = 80) -> str:
    value = BAD_NAME.sub("-", value)
    value = re.sub(r"\s+", " ", value).strip(" .-")
    return value[:limit].rstrip(" .-") or "untitled"


def output_root(cli_value: Optional[Path]) -> Path:
    if cli_value:
        return cli_value.expanduser().resolve()
    configured = os.environ.get("WECHAT_RESOURCE_DIR")
    if not configured:
        config_path = Path.home() / ".wechat-resource-archiver" / "config"
        if config_path.exists():
            for line in config_path.read_text(encoding="utf-8").splitlines():
                key, separator, value = line.partition("=")
                if separator and key.strip() == "WECHAT_RESOURCE_DIR":
                    configured = value.strip()
                    break
    return Path(configured).expanduser().resolve() if configured else (Path.cwd() / "resource").resolve()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_index(root: Path) -> dict:
    path = root / ".wechat-archive-index.json"
    if not path.exists():
        return {"urls": {}, "files": {}}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {"urls": {}, "files": {}}
    except (OSError, json.JSONDecodeError):
        return {"urls": {}, "files": {}}


def save_index(root: Path, index: dict) -> None:
    root.mkdir(parents=True, exist_ok=True)
    target = root / ".wechat-archive-index.json"
    temp = root / ".wechat-archive-index.tmp"
    temp.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(target)


def result(status: str, kind: str, path: Path, **extra) -> dict:
    return {"ok": True, "status": status, "kind": kind, "path": str(path), **extra}


def request(url: str, timeout: int) -> requests.Response:
    response = requests.get(url, headers={"User-Agent": UA, "Referer": "https://mp.weixin.qq.com/"}, timeout=timeout)
    response.raise_for_status()
    return response


def get_meta(soup: BeautifulSoup, property_name: str = "", name: str = "") -> str:
    attrs = {"property": property_name} if property_name else {"name": name}
    node = soup.find("meta", attrs=attrs)
    return str(node.get("content", "")).strip() if node else ""


def image_suffix(response: requests.Response, url: str) -> str:
    content_type = response.headers.get("content-type", "").split(";", 1)[0]
    known = {"image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp"}
    if content_type in known:
        return known[content_type]
    suffix = Path(urlparse(url).path).suffix.lower()
    return suffix if suffix in known.values() else ".bin"


def archive_url(url: str, root: Path, timeout: int) -> dict:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ArchiveError("需要有效的 http/https 链接")
    index = load_index(root)
    prior = index.setdefault("urls", {}).get(url)
    if prior and Path(prior).exists():
        return result("duplicate", "url", Path(prior), source=url)

    response = request(url, timeout)
    response.encoding = response.apparent_encoding or "utf-8"
    html = response.text
    soup = BeautifulSoup(html, "html.parser")
    is_wechat = parsed.netloc in {"mp.weixin.qq.com", "weixin.qq.com"}
    content = soup.select_one("#js_content") if is_wechat else soup.select_one("article, main")
    content = content or soup.body
    if content is None:
        raise ArchiveError("页面没有可归档正文，可能需要登录或访问验证")
    if is_wechat and soup.select_one("#js_content") is None:
        raise ArchiveError("微信页面未返回文章正文，可能遇到访问验证或文章已删除")

    title_node = soup.select_one("#activity-name, h1, title")
    title = get_meta(soup, property_name="og:title") or (title_node.get_text(" ", strip=True) if title_node else parsed.netloc)
    author = get_meta(soup, name="author") or (soup.select_one("#js_name").get_text(" ", strip=True) if soup.select_one("#js_name") else "")
    stamp = now()
    article_dir = root / "wechat" / f"{stamp.date().isoformat()}-{safe_name(title)}-{sha256_bytes(url.encode())[:8]}"
    assets = article_dir / "assets"
    article_dir.mkdir(parents=True, exist_ok=False)

    images = 0
    for node in content.find_all("img"):
        image_url = node.get("data-src") or node.get("src")
        if not image_url or str(image_url).startswith("data:"):
            continue
        try:
            image_response = request(str(image_url), timeout)
            images += 1
            assets.mkdir(exist_ok=True)
            filename = f"image-{images:03d}{image_suffix(image_response, str(image_url))}"
            (assets / filename).write_bytes(image_response.content)
            node["src"] = f"assets/{filename}"
            node.attrs.pop("data-src", None)
        except requests.RequestException:
            continue
    for node in content.select("script, style, iframe"):
        node.decompose()
    body = markdownify(str(content), heading_style="ATX", bullets="-").strip()
    metadata = {
        "title": title,
        "author": author,
        "source": response.url,
        "retrieved": stamp.isoformat(),
        "kind": "wechat-article" if is_wechat else "webpage",
        "images": images,
    }
    front = ["---"] + [f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in metadata.items()] + ["---", ""]
    (article_dir / "article.md").write_text("\n".join(front + [f"# {title}", "", body, ""]), encoding="utf-8")
    (article_dir / "source.html").write_text(html, encoding="utf-8")
    (article_dir / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    index["urls"][url] = str(article_dir)
    if response.url != url:
        index["urls"][response.url] = str(article_dir)
    save_index(root, index)
    return result("archived", metadata["kind"], article_dir, title=title, images=images, source=response.url)


def archive_file(source: Path, root: Path, note: str) -> dict:
    source = source.expanduser().resolve()
    if not source.is_file():
        raise ArchiveError(f"附件不存在：{source}")
    digest = sha256_bytes(source.read_bytes())
    index = load_index(root)
    prior = index.setdefault("files", {}).get(digest)
    if prior and Path(prior).exists():
        return result("duplicate", "file", Path(prior), sha256=digest)
    stamp = now()
    item_dir = root / "wechat" / f"{stamp.date().isoformat()}-{safe_name(source.stem)}-{digest[:8]}"
    item_dir.mkdir(parents=True, exist_ok=False)
    target = item_dir / safe_name(source.name, 120)
    shutil.copy2(source, target)
    mime = mimetypes.guess_type(source.name)[0] or "application/octet-stream"
    metadata = {"original_name": source.name, "stored_name": target.name, "mime_type": mime, "size": source.stat().st_size, "sha256": digest, "retrieved": stamp.isoformat(), "note": note}
    (item_dir / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (item_dir / "note.md").write_text(f"# {source.name}\n\n{note}\n" if note else f"# {source.name}\n", encoding="utf-8")
    index["files"][digest] = str(item_dir)
    save_index(root, index)
    return result("archived", "file", item_dir, filename=target.name, mime_type=mime, sha256=digest)


def archive_note(text: str, source: str, root: Path) -> dict:
    digest = sha256_bytes((source + "\n" + text).encode())
    index = load_index(root)
    prior = index.setdefault("files", {}).get(digest)
    if prior and Path(prior).exists():
        return result("duplicate", "note", Path(prior), sha256=digest)
    stamp = now()
    first_line = next((line.strip() for line in text.splitlines() if line.strip()), "微信转发记录")
    item_dir = root / "wechat" / f"{stamp.date().isoformat()}-{safe_name(first_line, 50)}-{digest[:8]}"
    item_dir.mkdir(parents=True, exist_ok=False)
    metadata = {"source": source, "retrieved": stamp.isoformat(), "sha256": digest, "kind": "forwarded-note", "original_media_available": False}
    front = ["---"] + [f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in metadata.items()] + ["---", ""]
    (item_dir / "note.md").write_text("\n".join(front + ["# 微信转发记录", "", text, ""]), encoding="utf-8")
    (item_dir / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    index["files"][digest] = str(item_dir)
    save_index(root, index)
    return result("archived", "note", item_dir, sha256=digest, original_media_available=False)


def main() -> int:
    parser = argparse.ArgumentParser(description="归档微信/ClawBot 转发的文章和资源")
    parser.add_argument("--output", type=Path, help="知识库 resource 目录")
    parser.add_argument("--timeout", type=int, default=30)
    sub = parser.add_subparsers(dest="command", required=True)
    url_parser = sub.add_parser("archive-url")
    url_parser.add_argument("url")
    file_parser = sub.add_parser("archive-file")
    file_parser.add_argument("path", type=Path)
    file_parser.add_argument("--note", default="")
    note_parser = sub.add_parser("archive-note")
    note_parser.add_argument("text")
    note_parser.add_argument("--source", default="wechat://forwarded-message")
    args = parser.parse_args()
    root = output_root(args.output)
    try:
        if args.command == "archive-url":
            value = archive_url(args.url, root, args.timeout)
        elif args.command == "archive-file":
            value = archive_file(args.path, root, args.note)
        else:
            value = archive_note(args.text, args.source, root)
        print(json.dumps(value, ensure_ascii=False, indent=2))
        return 0
    except (ArchiveError, requests.RequestException, OSError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
